---
name: Gourmet AI
colors:
  surface: '#fbf9f8'
  surface-dim: '#dbd9d9'
  surface-bright: '#fbf9f8'
  surface-container-lowest: '#ffffff'
  surface-container-low: '#f5f3f3'
  surface-container: '#efeded'
  surface-container-high: '#eae8e7'
  surface-container-highest: '#e4e2e2'
  on-surface: '#1b1c1c'
  on-surface-variant: '#4d4635'
  inverse-surface: '#303030'
  inverse-on-surface: '#f2f0f0'
  outline: '#7f7663'
  outline-variant: '#d0c5af'
  surface-tint: '#735c00'
  primary: '#735c00'
  on-primary: '#ffffff'
  primary-container: '#d4af37'
  on-primary-container: '#554300'
  inverse-primary: '#e9c349'
  secondary: '#006d36'
  on-secondary: '#ffffff'
  secondary-container: '#83fba5'
  on-secondary-container: '#00743a'
  tertiary: '#5e5e5b'
  on-tertiary: '#ffffff'
  tertiary-container: '#b4b3af'
  on-tertiary-container: '#454542'
  error: '#ba1a1a'
  on-error: '#ffffff'
  error-container: '#ffdad6'
  on-error-container: '#93000a'
  primary-fixed: '#ffe088'
  primary-fixed-dim: '#e9c349'
  on-primary-fixed: '#241a00'
  on-primary-fixed-variant: '#574500'
  secondary-fixed: '#83fba5'
  secondary-fixed-dim: '#66dd8b'
  on-secondary-fixed: '#00210c'
  on-secondary-fixed-variant: '#005227'
  tertiary-fixed: '#e4e2dd'
  tertiary-fixed-dim: '#c8c6c2'
  on-tertiary-fixed: '#1b1c19'
  on-tertiary-fixed-variant: '#474744'
  background: '#fbf9f8'
  on-background: '#1b1c1c'
  surface-variant: '#e4e2e2'
typography:
  h1:
    fontFamily: Space Grotesk
    fontSize: 40px
    fontWeight: '700'
    lineHeight: '1.1'
    letterSpacing: -0.02em
  h2:
    fontFamily: Space Grotesk
    fontSize: 32px
    fontWeight: '600'
    lineHeight: '1.2'
    letterSpacing: -0.01em
  h3:
    fontFamily: Space Grotesk
    fontSize: 24px
    fontWeight: '600'
    lineHeight: '1.3'
  body-lg:
    fontFamily: Inter
    fontSize: 18px
    fontWeight: '400'
    lineHeight: '1.6'
  body-md:
    fontFamily: Inter
    fontSize: 16px
    fontWeight: '400'
    lineHeight: '1.6'
  label-sm:
    fontFamily: Inter
    fontSize: 12px
    fontWeight: '600'
    lineHeight: '1.0'
    letterSpacing: 0.05em
rounded:
  sm: 0.25rem
  DEFAULT: 0.5rem
  md: 0.75rem
  lg: 1rem
  xl: 1.5rem
  full: 9999px
spacing:
  unit: 4px
  xs: 4px
  sm: 8px
  md: 16px
  lg: 24px
  xl: 48px
  container-margin: 20px
  gutter: 16px
---

## Brand & Style
The design system centers on an "Atmospheric Culinary" aesthetic, blending the precision of high-tech AI with the sensory richness of fine dining. It targets a sophisticated audience that values curation, speed, and aesthetic excellence.

The visual style is **Glassmorphism**, characterized by depth through translucency and layered materials. The interface should feel like a pane of frosted glass floating over a warm, ambient environment. The emotional response is one of effortless luxury—helpful without being intrusive, and state-of-the-art without feeling cold. Whites are kept soft to avoid digital eye strain, while the accent color provides a "Michelin-star" spark of energy.

## Colors
The palette is anchored by "Champagne White" and "Warm Stone" neutrals to create an inviting, appetizing canvas. 

- **Primary (Gourmet Gold):** Used for primary actions, premium badges, and high-value AI insights. It signifies quality and exclusivity.
- **Secondary (Emerald Mint):** Utilized for "Freshness" indicators, healthy choice tags, and success states.
- **Surface Strategy:** Backgrounds are never pure white (#FFF) in large blocks; instead, use the soft tertiary white (#F9F7F2) to maintain a premium, paper-like quality. 
- **Glass Effects:** Use the semi-transparent "glass" variable for floating headers, navigation bars, and modal overlays, paired with a 20px backdrop blur.

## Typography
The system employs a dual-font strategy. **Space Grotesk** is used for headlines to inject a technical, cutting-edge AI feel with its geometric apertures. **Inter** is used for all functional body text and interface labels to ensure maximum legibility and a neutral, professional tone.

- **Headlines:** Use tight letter spacing and high weights to create a "bold editorial" look.
- **Labels:** Small labels (like cuisine types or price levels) should be uppercase with slight letter spacing for a refined, organized appearance.

## Layout & Spacing
The design system utilizes a **Fluid Grid** with a generous 8px base unit. Layouts should prioritize whitespace to maintain a "high-end" feel—crowded interfaces are avoided.

- **Margins:** Mobile screens use a 20px side margin.
- **Hierarchy:** Use 'xl' spacing (48px) to separate major sections, such as "Recommended for You" and "Trending Nearby," to let the photography breathe.
- **Alignment:** All elements should align to the soft grid, but glass panels may "break" the grid slightly with padding to account for their translucent borders.

## Elevation & Depth
Depth is conveyed through **Backdrop Blurs** and **Ambient Shadows** rather than stark dark casting.

1.  **Level 1 (Base):** The main background.
2.  **Level 2 (Cards/Panels):** Glassmorphic surfaces with a 1px solid white border at 20% opacity. A very soft, diffused shadow (Blur: 30px, Y: 10px, Color: #4A4A4A at 5% opacity) provides lift.
3.  **Level 3 (Overlays/Modals):** Increased backdrop blur (40px) and a slightly more pronounced shadow to isolate the AI's "Deep Dive" restaurant insights.

Visual interest is created by the "tint" of the background bleeding through the glass panels.

## Shapes
The shape language is ultra-smooth and approachable. 
- **Cards & Major Panels:** Use a 24px radius (`rounded-xl` equivalent) to evoke a friendly, modern feel.
- **Buttons & Inputs:** Use a 16px radius (`rounded-lg`).
- **Contextual Chips:** Use pill-shapes (full radius) for restaurant tags (e.g., "Organic", "Michelin Guide") to distinguish them from actionable buttons.

## Components
- **Buttons:** Primary buttons use a solid 'Gourmet Gold' fill with white text. Secondary buttons use a glassmorphic style with a 1px border.
- **Glass Cards:** The signature component for restaurant listings. Includes a high-resolution food image with a glassmorphic overlay at the bottom for the name and rating.
- **AI Recommendation Chips:** Pill-shaped, using a subtle gradient from 'Emerald Mint' to a lighter green to indicate AI-driven confidence scores.
- **Search Bar:** A large, floating glass element with a 24px radius and a soft inner shadow to suggest depth.
- **Rating Stars:** Custom-designed icons using the 'Gourmet Gold' color, utilizing a thin-stroke style to match the tech-forward typography.
- **Taste Profile Sliders:** Custom sliders for flavor profiles (e.g., Spicy, Sweet) using rounded tracks and Gold thumb-indicators.